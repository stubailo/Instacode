cd ~/Documents/InstaCode/vagrant_env
vagrant up
open /Applications/Brackets.app/